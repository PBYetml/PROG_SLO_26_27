#pragma once
/*
 * Forme.h
 *
 *  Created on: 03.11.26
 *      Author: guifavre
 */

#ifndef INC_FORME_H_
#define INC_FORME_H_



#endif /* INC_FORME_H_ */

#include "Main.h"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

//#define

//struct / code

//prototype

void AffTriangleAngleGH(uint8_t nbr_etoile);
void AffTriangleAngleGB(uint8_t nbr_etoile);
void AffTriangleAngleDH(uint8_t nbr_etoile);
void AffTriangleAngleDB(uint8_t nbr_etoile);
void AffCarre(uint8_t nbr_etoile);
void AffParallelG(uint8_t nbr_etoile);
void AffParallelD(uint8_t nbr_etoile);
void AffLosangeP(uint8_t nbr_etoile);

