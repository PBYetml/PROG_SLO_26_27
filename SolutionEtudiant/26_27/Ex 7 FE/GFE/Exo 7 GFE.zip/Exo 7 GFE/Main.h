#pragma once
/*
 * Main.h
 *
 *  Created on: 03.11.26
 *      Author: guifavre
 */

#ifndef INC_MAIN_H_
#define INC_MAIN_H_



#endif /* INC_MAIN_H_ */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

 //#define

 //struct / code

 //prototype



