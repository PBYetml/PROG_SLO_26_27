//--------------------------------------------------------------------------------//
// Project Name				: Exo 7
// File name				: Main.c
// Date of creation			: 03.11.2026
// Date of modification		: DD.MM.YYYY
// 
// Auteur					: GFE
// 
// Version					: 1.0
// 
// Description				: exercice PROG 7
// 
// Remarque					: 
// 
//--------------------------------------------------------------------------------80//

//--- Include ---//

#include <stdio.h>
#include <stdint.h>

//--- Private Include ---//

#include "Main.h"
#include "Forme.h"

//--- Private Typedef ---//



//--- Private Variable ---//



void main()
{
	//AFFetoile(10);
	AffLosangeN(31);
}