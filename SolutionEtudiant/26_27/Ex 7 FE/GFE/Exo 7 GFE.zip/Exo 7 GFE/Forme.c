//--------------------------------------------------------------------------------//
// Project Name				: Exo 7
// File name				: Forme.c
// Date of creation			: 03.11.2026
// Date of modification		: DD.MM.YYYY
// 
// Auteur					: GFE
// 
// Version					: 1.0
// 
// Description				: exercice PROG 7
// 
// Remarque					: 
// 
//--------------------------------------------------------------------------------80//

//--- Include ---//

#include <stdio.h>
#include <stdint.h>

//--- Private Include ---//



//--- Private Typedef ---//



//--- Private Variable ---//

void AFFetoile(uint8_t nbr_etoile)
{
	for (uint8_t etoile = 0; etoile < nbr_etoile; etoile++)
	{
		printf("*");
	}
}

void AFFspace(uint8_t nbr_space)
{
	for (uint8_t space = 0; space < nbr_space; space++)
	{
		printf(" ");
	}
}

void AffTriangleAngleGH(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t etoile_l;

	for (ligne = nbr_etoile; ligne > 0; ligne--)
	{
		for (etoile_l = 0; etoile_l < ligne; etoile_l++)
		{
			printf("*");
		}
		printf("\n");
	}
}

void AffTriangleAngleGB(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t etoile_l;

	for (ligne = 0; ligne < nbr_etoile; ligne++)
	{
		for (etoile_l = 0; etoile_l <= ligne; etoile_l++)
		{
			printf("*");
		}
		printf("\n");
	}
}

void AffTriangleAngleDH(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t etoile_l;
	uint8_t space_l;
	uint8_t passed_l = 0;

	for (ligne = nbr_etoile; ligne > 0; ligne--)
	{
		for (space_l = 0; space_l < passed_l; space_l++)
		{
			printf(" ");
		}
		for (etoile_l = 0; etoile_l < ligne; etoile_l++)
		{
			printf("*");
		}
		printf("\n");
		passed_l++;
	}
}

void AffTriangleAngleDB(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t etoile_l;
	uint8_t space_l;
	uint8_t passed_l;

	passed_l = nbr_etoile;

	for (ligne = 0; ligne < nbr_etoile; ligne++)
	{
		for (space_l = 0; space_l < passed_l; space_l++)
		{
			printf(" ");
		}
		for (etoile_l = 0; etoile_l <= ligne; etoile_l++)
		{
			printf("*");
		}
		printf("\n");
		passed_l--;
	}
}

void AffCarre(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t flag_l = 0;

	for (ligne = 0; ligne < nbr_etoile * nbr_etoile; ligne++)
	{
		printf("*");
		flag_l++;
		if (flag_l == nbr_etoile)
		{
			printf("\n");
			flag_l = 0;
		}
	}
}

void AffParallelG(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t flag_l = 0;
	uint8_t space_l;
	uint8_t passed_l = 0;

	for (ligne = 0; ligne < nbr_etoile * nbr_etoile; ligne++)
	{
		printf("*");
		flag_l++;
		if (flag_l == nbr_etoile)
		{
			printf("\n");
			flag_l = 0;
			for (space_l = 0; space_l <= passed_l; space_l++)
			{
				printf(" ");
			}
			passed_l++;
		}
	}
}

void AffParallelD(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t flag_l = 0;
	uint8_t space_l;
	uint8_t passed_l;

	passed_l = nbr_etoile;

	for (space_l = 0; space_l <= passed_l - 2; space_l++)
	{
		printf(" ");
	}

	for (ligne = 0; ligne < nbr_etoile * nbr_etoile; ligne++)
	{
		if (flag_l == nbr_etoile)
		{
			printf("\n");
			flag_l = 0;
			for (space_l = 0; space_l <= passed_l - 3; space_l++)
			{
				printf(" ");
			}
			passed_l--;
		}
		printf("*");
		flag_l++;
	}
}

void AffLosangeP(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t flag_l = 0;
	uint8_t passed_l = 0;
	uint8_t img_etoile_l = 0;
	uint8_t img_space_l = 0;

	img_etoile_l = nbr_etoile % 2;
	img_space_l = nbr_etoile / 2;

	for (ligne = (nbr_etoile / 2) + 1; ligne > 0; ligne--)
	{
		AFFspace(img_space_l+1);
		AFFetoile(img_etoile_l);
		printf("\n");
		img_space_l--;
		img_etoile_l += 2;
	}

	img_etoile_l = nbr_etoile;
	img_space_l = 0;

	for (ligne = 0; ligne < (nbr_etoile / 2) + 1; ligne++)
	{
		AFFspace(img_space_l+1);
		AFFetoile(img_etoile_l);
		printf("\n");
		img_space_l++;
		img_etoile_l -= 2;
	}

}

void AffLosangeN(uint8_t nbr_etoile)
{
	uint8_t ligne;
	uint8_t flag_l = 0;
	uint8_t passed_l = 0;
	uint8_t img_etoile_l = 0;
	uint8_t img_space_l = 0;

	img_etoile_l = nbr_etoile / 2;
	img_space_l = nbr_etoile % 2;

	for (ligne = (nbr_etoile / 2) + 1; ligne > 0; ligne--)
	{
		AFFetoile(img_etoile_l+1);
		AFFspace(img_space_l);
		AFFetoile(img_etoile_l+1);
		printf("\n");
		img_space_l+=2;
		img_etoile_l--;
	}

	img_etoile_l = 0;
	img_space_l = nbr_etoile;

	for (ligne = 0; ligne < (nbr_etoile / 2) + 1; ligne++)
	{
		AFFetoile(img_etoile_l+1);
		AFFspace(img_space_l);
		AFFetoile(img_etoile_l+1);
		printf("\n");
		img_space_l-=2;
		img_etoile_l++;
	}

}