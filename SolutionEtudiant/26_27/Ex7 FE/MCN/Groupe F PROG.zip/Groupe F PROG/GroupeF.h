uint8_t AffParalleG_MCN(uint8_t EtoileMax); //EtoileMax 0-209
char AffTriangleG_MCN(char EtoileMax);