//-----------------------------------------------------------------------------------//
// Nom du projet 		: 
// Nom du fichier 		: 
// Date de cr�ation 	: 30.09.2015
// Date de modification : 07.01.2016
//
// Auteur 				: Philou (Ph. Bovey)
//
// Version				: x.x
//
// Description          : 
//
//
// Remarques :            lien pour la table ASCII :
// 						  -> http://www.asciitable.com/
// 						  lien pour la saisie de clavier avec getc & getchar pour ne pas
//                        avoir des erreurs d'interpr�tation
// 						  -> http://fr.openclassrooms.com/informatique/cours/utiliser-les-bonnes-fonctions-d-entree
// 						  lien vers diff�rents
// 						  -> http://fr.wikipedia.org/wiki/String.h
//----------------------------------------------------------------------------------//

//--- librairie standart ---//
#include <stdio.h>	// pour usage printf et scanf_s
#include <stdint.h>                    // Nouveaut� du VC++ 2005, 2008, 2010 et 2015 : le scanf_s remplace scanf
#include "GroupeF.h"

int main(void)
{
    AffParalleG_MCN(210);
  return(0);
}
uint8_t AffParalleG_MCN(uint8_t EtoileMax)// only works for terminal 209 chars long (fullscreen)
{
    if (EtoileMax > 205)
    {
        EtoileMax = 205;
    }
    for (uint8_t iteration = 0; iteration < EtoileMax; iteration++)
    {
        for (uint8_t iteration2 = 0; iteration2 < 5; iteration2++)
        {
            printf("*");
        }
        printf("\n\r");
        for (uint8_t iteration3 = 0; iteration3 <= iteration; iteration3++)
        {
            printf(" ");
        }
    }
}
char AffTriangleG_MCN(char EtoileMax)
{
    uint8_t EtoileMax2 = EtoileMax;
    for (uint8_t iteration = 0; iteration < EtoileMax; iteration++)
    {
        for (uint8_t iteration2 = EtoileMax2; iteration2 > 0; iteration2--)
        {
            printf("*");
        }
        EtoileMax2 = EtoileMax2 - 1;
        printf("\n\r");
        for (uint8_t iteration3 = 0; iteration3 <= iteration; iteration3++)
        {
            printf(" ");
        }
    }
}